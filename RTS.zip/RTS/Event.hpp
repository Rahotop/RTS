#ifndef EVENT_HPP_INCLUDED
#define EVENT_HPP_INCLUDED

#include <SFML/Window.hpp>

//Déclaration de la classe Scene
class Scene;

//Enumeration des touches utiles pour l'execution du programme
enum Touche
{
	ECHAP,
	ClickG,
	ClickD,
	END
};

//Classe qui gère les évennements
class Event : public sf::Event
{
	public:
	
	//Constructeur qui prend en paramètre une scene hérite de la classe SFML sf::Window
	Event(Scene *w);
	
	//Methode de mise à jour des events
	void update();
	//Methode qui retourne l'état de la fenetre
	bool isRunning();
	//Stoppe la fenetre
	void stop();
	
	private:
	
	Scene *m_win;
	bool m_running;
    sf::Clock m_clock;
    int m_fps;
};

#endif
