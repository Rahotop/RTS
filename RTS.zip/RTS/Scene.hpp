#ifndef SCENE_HPP_INCLUDED
#define SCENE_HPP_INCLUDED

#define GLM_FORCE_RADIANS

#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <GL/glew.h>
#include <GL/glut.h>
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include "Shader.hpp"
#include "Cube.hpp"
#include "Event.hpp"
#include "Map.hpp"

//Classe représentant une scene OpenGL dans une fenetre SFML
class Scene : public sf::Window
{
	public:
	
	//Constructeur qui prend en parametre la taille de la fenetre, le titre, le style et le contexte OpenGL
	Scene(sf::VideoMode mode, std::string title, sf::Uint32 style, sf::ContextSettings settings);
	~Scene();
	
	//Boucle de rendu
	void boucle();
	//Changer la résolution de la fenetre, utile en cas de redimensionnement
	void changeViewPort(int x, int y);
	
	private:
	
	//Matrices utiles au rendu
	glm::mat4 m_projection;
	glm::mat4 m_modelview;
	
	//Objet event pour gerer les evennements sur la fenetre
	Event m_event;
};

#endif
