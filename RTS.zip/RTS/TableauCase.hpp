#ifndef TABLEAU_CASE_HPP_DEFINE
#define TABLEAU_CASE_HPP_DEFINE

#include "Case.hpp"

class TableauCase
{

	public:
	
	//Constructeur par defaut
	TableauCase();
	//Constructeur qui prend en parametre sa taille et sa couleur
	TableauCase(int taille, float couleur[3]);
	~TableauCase();
	//Ajout de case
	void addCase(int x, int y);
	void addCase(const Case& c);
	void initUBO(); //Initialisation de l'ubo
	GLuint getUBO(); //Accesseur à l'ubo
	float* getColor(); //Accesseur à la couleur
	
	int getTaille();
	int getSizeof();
	
	//Surcharge de l'operateur =
	TableauCase& operator=(const TableauCase& t);
	
	private:
	
	Case *m_tab_c;
	int m_taille;
	float *m_couleur;
	GLuint *m_tabGL;
	int m_tmpRemplissage;
	GLuint m_ubo;
};

#endif
