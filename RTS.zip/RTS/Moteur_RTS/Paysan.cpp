#include "Paysan.hpp"

Paysan::Paysan(const Position& p) : Unite(50, 1, 6, 1.2, p, 2)
{

}
