#ifndef SOIGNEUR_HPP_INCLUDED
#define SOIGNEUR_HPP_INCLUDED

#include "Roi.hpp"


class Soigneur : public Unite
{

	public:
	
	Soigneur(const Position& p);

};

#endif
