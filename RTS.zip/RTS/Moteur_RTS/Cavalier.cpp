#include "Cavalier.hpp"

Cavalier::Cavalier(const Position& p) : Unite(120, 1, 10, 2.5, p, 4)
{

}
