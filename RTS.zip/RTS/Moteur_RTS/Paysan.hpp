#ifndef PAYSAN_HPP_INCLUDED
#define PAYSAN_HPP_INCLUDED

#include "Roi.hpp"

class Paysan : public Unite
{

	public :
	
	Paysan(const Position& p);
	
	private :

};

#endif
