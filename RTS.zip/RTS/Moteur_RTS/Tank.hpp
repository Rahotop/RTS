#ifndef TANK_HPP_INCLUDED
#define TANK_HPP_INCLUDED

#include "Roi.hpp"


class Tank : public Unite
{

	public:
	
	Tank(const Position& p);

};

#endif
