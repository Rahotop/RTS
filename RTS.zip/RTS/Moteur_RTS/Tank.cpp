#include "Tank.hpp"

Tank::Tank(const Position& p) : Unite(180, 1, 6, 0.6, p, 8)
{

}
