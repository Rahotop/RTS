#ifndef CAPITAINE_HPP_INCLUDED
#define CAPITAINE_HPP_INCLUDED

#include "Roi.hpp"

class Capitaine : public Unite
{

	public :
	
	Capitaine(const Position& p);
	
	private :

};

#endif
