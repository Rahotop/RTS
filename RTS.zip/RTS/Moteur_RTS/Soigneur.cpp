#include "Soigneur.hpp"

Soigneur::Soigneur(const Position& p) : Unite(40, 5, -15, 0.7, p, 5)
{

}
