#include "Fantassin.hpp"

Fantassin::Fantassin(const Position& p) : Unite(100, 1, 20, 1.0, p, 7)
{

}
