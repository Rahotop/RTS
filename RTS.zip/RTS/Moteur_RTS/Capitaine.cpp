#include "Capitaine.hpp"

Capitaine::Capitaine(const Position& p) : Unite(100, 1, 10, 1.2, p, 3)
{

}
