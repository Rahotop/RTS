#include "Archer.hpp"

Archer::Archer(const Position& p) : Unite(80, 8, 10, 1.2, p, 6)
{

}
