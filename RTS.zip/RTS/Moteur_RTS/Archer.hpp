#ifndef ARCHER_HPP_INCLUDED
#define ARCHER_HPP_INCLUDED

#include "Roi.hpp"

class Archer : public Unite
{

	public:
	
	Archer(const Position& p);

};

#endif
