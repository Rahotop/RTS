#ifndef FANTASSIN_HPP_INCLUDED
#define FANTASSIN_HPP_INCLUDED

#include "Roi.hpp"


class Fantassin : public Unite
{

	public:
	
	Fantassin(const Position& p);

};

#endif
