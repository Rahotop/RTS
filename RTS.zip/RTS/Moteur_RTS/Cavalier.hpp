#ifndef CAVALIER_HPP_INCLUDED
#define CAVALIER_HPP_INCLUDED

#include "Roi.hpp"


class Cavalier : public Unite
{

	public :
	
	Cavalier(const Position& p);
	
	private :
	
};

#endif
