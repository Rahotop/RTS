#ifndef OBJET_HPP_INCLUDED
#define OBJET_HPP_INCLUDED

//Classe virtuelle représentant un objet affichable
class Objet
{
	public:
	
	//Methode à surcharger pour les affichable
	virtual void afficher(glm::mat4 modelview, glm::mat4 projection) = 0;
};

#endif
