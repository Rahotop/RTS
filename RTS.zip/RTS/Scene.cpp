#include "Scene.hpp"

//Constructeur
Scene::Scene(sf::VideoMode mode, std::string title, sf::Uint32 style, sf::ContextSettings settings) : sf::Window(mode, title, style, settings), m_projection(1.0), m_modelview(1.0), m_event(this)
{
	setFramerateLimit(60); //On limite le nombre de fps
	glewInit(); //On initialise glew
	Cube::init(); //On initailise la partie statique des cubes

    glEnable(GL_DEPTH_TEST); //On active le test de profondeur
    glEnable(GL_CULL_FACE); //On active le culling (anti-horaire)
}

Scene::~Scene()
{

}

void Scene::boucle()
{
	//On déclare une map
	Map p("Maps/map1.oui");
	
	//On initilise les matrices
    m_projection = glm::perspective(70.0, (double) getSize().x / getSize().y, 1.0, 3000.0);
    m_modelview = glm::mat4(1.0);
	
	
	int i(0);
    while (m_event.isRunning())
    {
    	i++;
    	m_event.update(); //On met à jour les events
        
        //On clear les différents buffer
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		
		//On initialise la matrice modelview pour que la caméra soit bien placée et regarde dans la bonne direction
		m_modelview = glm::lookAt(glm::vec3(30,30,30), glm::vec3(0,0,0), glm::vec3(0,0,1));
		
		m_modelview = glm::rotate(m_modelview, i/100.0f, glm::vec3(0,0,1));
		
		p.afficher(m_modelview, m_projection);//On affiche la map
        glUseProgram(0); //On arrête d'utiliser les shaders
        
        display(); // On affiche
    }
    
    Cube::erase(); //On supprime la partie statique du cube
}

void Scene::changeViewPort(int x, int y)
{
	glViewport(0, 0, x, y);
}



















