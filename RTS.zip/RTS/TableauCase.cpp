#include "TableauCase.hpp"

//Constructeur par defaut
TableauCase::TableauCase() : m_tab_c(nullptr), m_taille(0), m_couleur(nullptr), m_tabGL(nullptr), m_tmpRemplissage(0), m_ubo(0)
{

}

//Constructeur qui prend en parametre la taille du tableau, et la couleur
TableauCase::TableauCase(int taille, float couleur[3]): m_tab_c(new Case[taille]), m_taille(taille), m_couleur(new float[3]), m_tabGL(new GLuint[taille]), m_tmpRemplissage(0), m_ubo(0)
{
	for(int i(0);i<3;i++)
		m_couleur[i] = couleur[i];
}

TableauCase::~TableauCase()
{
	delete[] m_tab_c;
	delete[] m_couleur;
	delete[] m_tabGL;
	glDeleteBuffers(1, &m_ubo);
}

//On ajoute une case à la position x,y
void TableauCase::addCase(int x, int y)
{
	if(m_tmpRemplissage < m_taille)
	{
		m_tab_c[m_tmpRemplissage] = Case(x,y);
		m_tabGL[m_tmpRemplissage] = m_tab_c[m_tmpRemplissage].getPos();
		m_tmpRemplissage++;
	}
}

//On ajoute le cube pris en parametre
void TableauCase::addCase(const Case& c)
{
	if(m_tmpRemplissage < m_taille)
	{
		m_tab_c[m_tmpRemplissage] = c;
		m_tabGL[m_tmpRemplissage] = m_tab_c[m_tmpRemplissage].getPos();
		m_tmpRemplissage++;
	}
}

//Initialisation du ubo après avoir rempli le tableau
void TableauCase::initUBO()
{
	glGenBuffers(1, &m_ubo); //Generation UBO

    glBindBuffer(GL_UNIFORM_BUFFER, m_ubo); //Verrouillage UBO

        glBufferData(GL_UNIFORM_BUFFER, m_taille * sizeof(GLuint), 0, GL_STATIC_DRAW); //Allocation memoire

        glBufferSubData(GL_UNIFORM_BUFFER, 0, m_taille * sizeof(GLuint), m_tabGL); //Transfert données

    glBindBuffer(GL_UNIFORM_BUFFER, 0);
}

GLuint TableauCase::getUBO()
{
	return m_ubo;
}

float* TableauCase::getColor()
{
	return m_couleur;
}

int TableauCase::getTaille()
{
	return m_taille;
}

int TableauCase::getSizeof()
{
	return sizeof(GLuint) * m_taille;
}

//Surcharge de l'operateur =
TableauCase& TableauCase::operator=(const TableauCase& t)
{
	//On supprime les partie dynamique si elles sont initialisées, et on les remplace avec les bonnes tailles
	if(m_tab_c != nullptr)
		delete[] m_tab_c;
	m_tab_c = new Case[t.m_taille];
	
	if(m_couleur == nullptr)
		m_couleur = new float[3];
	
	if(m_tabGL != nullptr)
		delete[] m_tabGL;
	m_tabGL = new GLuint[t.m_taille];
	
	m_taille = t.m_taille;
	
	m_tmpRemplissage = t.m_tmpRemplissage;
	
	//On copie les cases déjà remplies
	for(int i(0); i < m_tmpRemplissage; i++)
	{
		m_tab_c[i] = t.m_tab_c[i];
		m_tabGL[i] = t.m_tabGL[i];
	}
	
	//On copie la couleur
	for(int i(0); i < 3; i++)
	{
		m_couleur[i] = t.m_couleur[i];
	}
}























