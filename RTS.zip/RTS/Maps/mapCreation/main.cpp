#include "Map.hpp"
#include <ctime>

int main()
{
    srand(time(nullptr));
    Map m(300,"biome.txt");
    m.initMap();
    m.remplissage();
    m.save("../map.txt","../mapObstacle.txt");
    return 0;
}
