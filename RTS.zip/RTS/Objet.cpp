#include "Objet.hpp"
#include "Map.hpp"

Map *Objet::s_map = nullptr;
