#include "Map.hpp"

//constructeur par defaut, pour les tests
Map::Map() : m_tabC(new TableauCase[1]), m_shaderMap("Shaders/Map.vert", "Shaders/Map.frag"), m_nbCouleur(1) //Utilisation du shader de la map
{
	float tmp[3] = {1.0,0.0,0.0}; //Couleur de base
	
	int taille = 20; //Taille de la map (taille*taille)
	
	m_tabC[0] = TableauCase(taille*taille, tmp); //Déclaration d'un tableauCase pour la couleur
	
	for(int i(0); i < taille; i++)
	{
		for(int j(0); j < taille; j++)
		{
			m_tabC[0].addCase(i,j); //Ajout des cases, pour avoir un plan
		}
	}
	
	m_tabC[0].initUBO(); //Initialisation des positions dans un buffer
}

Map::Map(std::string path) : m_tabC(nullptr), m_shaderMap("Shaders/Map.vert", "Shaders/Map.frag"), m_nbCouleur(0)
{
	std::ifstream in(path.c_str());
	
	in >> m_nbCouleur;
	
	m_tabC = new TableauCase[m_nbCouleur];
	
	for(int i(0); i < m_nbCouleur; i++)
	{
		int nbCases(0), couleur[3];
		in >> nbCases >> couleur[0] >> couleur[1] >> couleur[2];
		
		float tmp[3] = {couleur[0]/255.0f, couleur[1]/255.0f, couleur[2]/255.0f};
		
		m_tabC[i] = TableauCase(nbCases, tmp);
		
		for(int j(0); j < nbCases; j++)
		{
			int x,y;
			in >> x >> y;
			m_tabC[i].addCase(x, y);
		}
		m_tabC[i].initUBO();
	}
}

Map::~Map()
{
	delete[] m_tabC;
}

void Map::afficher(glm::mat4 modelview, glm::mat4 projection)
{
	glUseProgram(m_shaderMap.getID()); //On utilise le shader de la map
		
            glBindBuffer(GL_ARRAY_BUFFER, Cube::getVBO()); //Verrouillage du vbo des sommets

                glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, 0); //Utilisation du vbo pour les sommets
                glEnableVertexAttribArray(0);
                
					glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, Cube::getIBO()); //Verrouillage du ibo pour la définition des triangles
						
						
						for(int i(0); i < m_nbCouleur; i++)
						{
							//Initialisation du binding point
				
							GLuint bindingPoint = 0;
							GLint index = glGetUniformBlockIndex(m_shaderMap.getID(), "pos");
							glUniformBlockBinding(m_shaderMap.getID(), index, bindingPoint);
				
						    glBindBufferRange(GL_UNIFORM_BUFFER, bindingPoint, m_tabC[i].getUBO(), 0, m_tabC[i].getTaille()); //Utilisation du binding point avec le vbo des positions
					
					        glUniformMatrix4fv(0, 1, GL_FALSE, glm::value_ptr(projection)); //Envoi de la matrice de projection au shader
					        glUniformMatrix4fv(1, 1, GL_FALSE, glm::value_ptr(modelview)); //Envoi de la matrice modelview au shader
					        glUniform3fv(2, 1, m_tabC[i].getColor()); //Envoi de la couleur au shader
						
							glDrawElementsInstanced(GL_TRIANGLES, 36, GL_UNSIGNED_BYTE, 0, m_tabC[i].getTaille()); //Dessin des cubes instanciés
						}
					
					glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0); //On deverrouille le ibo
				
				glDisableVertexAttribArray(0); //On arrête d'utiliser le vbo
				
			glBindBuffer(GL_ARRAY_BUFFER, 0); //On deverrouille le vbo
	
	//On arrête d'utiliser le shader dans la fonction appelante 
}









