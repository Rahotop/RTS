#include "Event.hpp"
#include "Scene.hpp"

//Constructeur qui prend un scene en parametre
Event::Event(Scene *w) : sf::Event(), m_win(w), m_running(true), m_clock(), m_fps(0)
{
	
}

//Mise à jour des events
void Event::update()
{
	//Gestion des events
	
	while(m_win->pollEvent(*this))
    {
        if(this->type == sf::Event::Closed)
        {
            m_running = false;
        }
        else if(this->type == sf::Event::Resized)
        {
            m_win->changeViewPort(this->size.width, this->size.height);
        }
    }
    
    //Comptage et affichage des fps
    
    if(m_clock.getElapsedTime().asSeconds() >= 1.0f)
    {
        std::cout << "fps : " << m_fps+1 << std::endl;
        m_clock.restart();
        m_fps = 0;
    }
    else
        m_fps++;
}

//Retourne l'état de la fenetre
bool Event::isRunning()
{
	return m_running;
}

//Stoppe la fenetre
void Event::stop()
{
	m_running = false;
}

